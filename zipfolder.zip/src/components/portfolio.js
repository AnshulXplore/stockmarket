import React, { useEffect, useContext, useState } from 'react';
import stockContext from "./stockContext";
import './style/transiction.css';
import SecondNav from './secondnav';

export default function Portfolio(props) {
    // const [reasult, setreasult] = useState("");
    const[amount,setamount]=useState(0);
    const a = useContext(stockContext);
    const [reasult, setreasult] = useState("");
    const[income,setIncome]=useState(0);
    

    useEffect(() => {
        const fetchdata = async () => {
            const data = await fetch('http://localhost:5000/userdetail/totalsharedetail', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json', 'auth-token': a.jwtToken }
            });
            const response = await data.json();
            setreasult(response);
            // setamount(response.amount);
            console.log(response)

            response.map((e)=>{

                if(e.number===0){

                }
                else{
                console.log(a.myobj[e.name])
                let totalincome=a.myobj[e.name]-e.average
                totalincome=totalincome*e.number
                setIncome(income=>income+totalincome)
                setamount(amount=>e.amount+amount)
                // console.log(e.amount)
                }
            })
            
        };
        fetchdata();



        
    }, [a.jwtToken]);

   

if(reasult && reasult.length>0 ){
    return (
        <>
            <SecondNav home={'Stocks And Performance'} backColor={'rgb(11 7 62 / 81%)'} textColor={'white'} hoverColor={'pink'}/>
            <div className="wrapper rounded">
                <nav className="navbar navbar-expand-lg navbar-dark dark d-lg-flex align-items-lg-start">
                    <a className="navbar-brand" href="#!">Transactions
                        <p className="text-muted pl-1">Welcome to your transactions</p>
                    </a>
                </nav>

                <div className="row mt-2 pt-2">
                    <div className="col-md-6" id="income">
                        <div className="d-flex justify-content-start align-items-center">
                            <p className="fa fa-long-arrow-down"></p>
                            <p className="text mx-3">Income</p>
                            <p className="text-white ml-4 money">{income<0 ? income:income-amount}</p>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="d-flex justify-content-md-end align-items-center">
                            <div className="fa fa-long-arrow-up"></div>
                            <div className="text mx-3">Invested Value</div>
                            <div className="text-white ml-4 money">${amount}</div>
                        </div>
                    </div>
                </div>
                         <div style={{display:'flex',justifyContent:'space-evenly',backgroundColor:'white',position:'relative',left:'12px'}}>
                            <p className='my-3'>Stock Name</p>
                            <p className='my-3'>Qunatity</p>
                            <p className='my-3'>Investment Amount</p>
                            <p className='my-3'>Market Price</p>
                            <p className='my-3'>Avg Price</p>
                            <p className='my-3'>Profit/Loss</p>
                         </div> 


                         {reasult.map((e, index) => {
                            // { setamount(amount+e.amount)}
                        if (e.number !== 0) {
                            let incomee=a.myobj[e.name]-e.average;
                            // console.log(a.myobj[e.name])
                            incomee=incomee*e.number;
                            // console.log(incomee)
                            // setIncome(incomee)
                            return (
                                <div className='my-2' style={{ backgroundColor: 'black', display: 'flex', justifyContent: 'space-evenly',borderRadius:'8px' }}>
                                    <p className='my-3' style={{ color: 'white', position: 'relative', right: '10px' }}>{e.name}</p>
                                    <p className='my-3' style={{ color: 'white', position: 'relative', right: '5px' }}>{e.number}</p>
                                    <p className='my-3' style={{ color: 'white', position: 'relative', left: '24px' }}>{e.amount}</p>
                                    <p className='my-3' style={{ color: 'white', position: 'relative', left: '60px' }}>{a.myobj[e.name]}</p>
                                    <p className='my-3' style={{ color: 'white', position: 'relative', left: '60px' }}>{e.average}</p>
                                    <p className='my-3' style={{ color: 'white', position: 'relative', left: '40px' }}>${incomee}</p>
                                </div>
                                    );
                        } else {
                            return null;
                            }
                            })}                  
                
            </div>
        </>
    );
}
else{
    return (
        <>
        <SecondNav home={'Stocks And Performance'} backColor={'rgb(11 7 62 / 81%)'} textColor={'white'} hoverColor={'pink'}/>
        <h4 style={{display:'flex',justifyContent:'center',alignItems:'center',position:'relative',top:'180px'}}>No Executed orders. Place an order from Anshul Recommendation </h4>
        <button style={{border:'none',backgroundColor:'#E91E63',position:'relative',top:'180px',left:'620px'}}><a className='underline-animation' style={{color:'white',fontWeight:'bold',textDecoration:'none'}} href="/">GO TO Home</a></button>
        
        </>
    )
}
}

    
        
    


