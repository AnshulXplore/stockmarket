import {createContext} from 'react'

const stockContext=createContext();

export default stockContext;