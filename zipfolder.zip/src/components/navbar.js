import React, { Component } from 'react'
// import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'

export  class navbar extends Component {
  
  // static propTypes = {

  // }

  render() {
    return (
      <div style={{position:'sticky'}}>
      <nav style={{display:'flex',alignItems:'center',justifyContent:'space-evenly'}}>
      <img src="https://w3assets.angelone.in/wp-content/uploads/2024/04/IPL_COMPOSITE-LOGO_ANGELONE_HORIZONTAL_WHITE_VERSION-192x100-1.png" title="Angel One - Share Market Trading" width="192px" height="100px" style={{maxwidth:"192px"}}/>
<form className="elasticsearch-desktop">
<input type="search" placeholder="Search Stocks, News, Reports…" className='my-2' style={{width:"400px",borderRadius:'8px',height:'40px',textAlign:'center',position:'relative',top:'0px'}}/>
<div className="elasticsearch-loader"></div>
<button type="button" className="elasticsearch-close" style={{display: "none",position:'relative'}}>
<svg width="13" height="1" viewBox="0 0 13 14" fill="transparent" xmlns="http://www.w3.org/2000/svg">
<path d="M12.3229 1.71998L11.2692 0.599976L6.30141 5.87998L1.33367 0.599976L0.279907 1.71998L5.24765 6.99998L0.279907 12.28L1.33367 13.4L6.30141 8.11997L11.2692 13.4L12.3229 12.28L7.35518 6.99998L12.3229 1.71998Z" fill="transparent"></path>
</svg>
</button>


<button type="submit" style={{position: "absolute",bottom:'545px' ,left: "370px",border:'none'}}>
<svg width="21" height="21" viewBox="0 0 21 21" fill="transparent" xmlns="http://www.w3.org/2000/svg">
<path d="M20 20L15.514 15.506L20 20ZM18 9.5C18 11.7543 17.1045 13.9163 15.5104 15.5104C13.9163 17.1045 11.7543 18 9.5 18C7.24566 18 5.08365 17.1045 3.48959 15.5104C1.89553 13.9163 1 11.7543 1 9.5C1 7.24566 1.89553 5.08365 3.48959 3.48959C5.08365 1.89553 7.24566 1 9.5 1C11.7543 1 13.9163 1.89553 15.5104 3.48959C17.1045 5.08365 18 7.24566 18 9.5V9.5Z" stroke="#777D87" strokeWidth="2" strokeLinecap="round"></path>
</svg>
</button>
</form>
<button style={{backgroundColor:'blue',color:'white',textAlign:'center',cursor:'pointer',width:'200px',height:'40px',borderRadius:'4px',border:'none'}}><Link to="/signup" style={{textDecoration:'none',color:'white'}}>open demat Account</Link> </button>
<button style={{color:'blue',textAlign:'center',cursor:'pointer',width:'160px',height:'40px',borderRadius:'4px',border:'none'}}><Link to="/signup" style={{textDecoration:'none',color:'blue'}}>Login</Link></button>
      </nav>
      </div>
    )
  }
}

export default navbar
