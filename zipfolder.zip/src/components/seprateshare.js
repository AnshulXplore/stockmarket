import React, { useState, useEffect, createContext ,useContext} from 'react';
import Navbar from './navbar';
import Second from './secondnav';
import Buy from './buy';
import { componentDidMount as fetchShareData } from './about';
import { Link } from 'react-router-dom';
import stockContext from "./stockContext";
let shareName = null;

export const ResponseContext = createContext();

const SeprateShare = (props) => {
  const a=useContext(stockContext);
  const [arr, setArr] = useState([]);
  const [name, setName] = useState('');
  const [isopen, setIsOpen] = useState(false);
  const [Action, setAction] = useState('BUY');
  const [arrowState, setArrowState] = useState(1);
  const[isSell,setIsSell]=useState(false);
  const[onesharenum,setsharenum]=useState(0);
  

  const setmyContext = (res) => {
    setIsOpen(res);
  };

  const setResponse = (response) => {
    setIsOpen(response);
    return isopen;
  };

  const handleOnClick = () => {
    setIsOpen(true);
    setAction('BUY');
  };

  const handle = () => {
    setIsOpen(false);
    setAction('BUY');
  };

  const sellHandle = () => {
    setIsOpen(true);
    setAction('SELL');
  };
  const manageWatchList = () => {
   a.getStock(name,name,40,50);
  };
 
  const joker = () => {
    setIsOpen(false);
  };

  useEffect(() => {
    const fetchData = async () => {
      props.setProgress(10);
      let shareData = await fetchShareData(props.name);
      props.setProgress(50);
      let data = [shareData];
      setArr(data);
      props.setProgress(70);
      setName(props.name);
      props.setProgress(100);
      //  if(this.state.arr.length>0){

  //  let difference=parseInt(this.state.arr[0][1]-this.state.arr[0][2])
  //  console.log('diff'+difference)
  //  let averageLength=500/difference;
  //  console.log('avragelength'+averageLength)
  //  let close=parseInt(this.state.arr[0][3]-this.state.arr[0][2]);
  //  console.log('colse'+close)
  //  let finalCal=close*averageLength;
  //  console.log('final'+finalCal);
  //  this.setState({arrowState:finalCal+19});
  //  console.log(this.state.arrowState);
  // }
    };

    fetchData();
  }, []);

  useEffect(()=>{
    const fetchTotalNumOfShare=async()=>{
      const data = await fetch('http://localhost:5000/userdetail/onesharedetail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'auth-token': a.jwtToken },
        body:JSON.stringify({shareName:props.name})
    });
    const response = await data.json();
    console.log(response)
    if(response){
    if(response>0){
      setIsSell(true); 
      setsharenum(response);
    }
    else{
      setIsSell(false);
    }
  }
    
    }
    fetchTotalNumOfShare();
  },[])

  const normal = {
    backgroundColor: '#fff',
    height: '30px',
    width: '40px',
    border: '1px solid #e0e0ec',
    borderRadius: '4px',
    alignContent: 'center',
    transition: 'all .25s ease-in-out',
    cursor: 'pointer'
  };
  const hover = {
    border: '1px solid blue'
  };
  const handleMouseEnter = (e) => {
    const mergedStyle = { ...normal, ...hover };
    Object.assign(e.target.style, mergedStyle);
  };

  const handleMouseLeave = (e) => {
    Object.assign(e.target.style, normal);
  };

  const {
    fullName,
    keyName,
    avaliableMoney,
    amountSet,
    setindex,
    index,
    setProgress,
  } = props;

  setProgress(0);

  shareName = name;

  if (arr.length > 0) {
    return (
      <>
        <ResponseContext.Provider value={{ setmyContext }}>
          {isopen && Action === 'BUY' ? (
            <div style={{ position: 'relative', zIndex: '1000' }}>
              {isopen ? (
                <Buy Index={index} setIndex={setindex} amountSetter={amountSet} avaliableAmount={avaliableMoney} keyname={keyName} currentPrice={'40'} name={name} shareprice={'400'} Action={Action} shareNumber={onesharenum}/>
              ) : null}
            </div>
          ) : (
            <div style={{ position: 'relative', zIndex: '1000' }}>
              {isopen ? (
                <Buy Index={index} setIndex={setindex} avaliableAmount={avaliableMoney} price={'50'} keyname={keyName} Action={Action} currentPrice={'40'} name={name} shareprice={'400'} shareNumber={onesharenum}/>
              ) : null}
            </div>
          )}
        </ResponseContext.Provider>

          <div style={{ position: 'relative',bottom: isopen ? '400px' : '0px',overflowX: 'hidden',opacity: isopen ? '0.5' : '1',
                        pointerEvents: isopen ? 'auto' : 'auto'}}>
          <Navbar />
          <Second home={"HOME"} backColor={'#21b7a8'} textColor={'black'} hoverColor={'blue'} />
          <div style={{ position: 'relative', left: '20px', border: '2px solid black', top: '8px', overflowX: 'hidden',height:"780px",overflowY:'hidden' }}>
            <div style={{ display: 'flex' }}>
              
              <Link to='/' className='mx-3 my-2' style={{ textDecoration: 'none', color: '#3f5bd9', fontSize: '15px' }}>Home</Link>
              <Link to="/" className='mx-3 my-2' style={{ textDecoration: 'none', color: '#3f5bd9', fontSize: '15px' }}>All Stocks</Link>
              <p className='mx-3 my-2' style={{ fontSize: '15px', color: '#777d87' }}>{name}</p>
              <i className="fa-sharp fa-solid fa-plus" onClick={manageWatchList}></i>
            </div>
            <div style={{ display: 'flex' }}>
              <h1 className='mx-3' style={{ fontSize: '26px', fontWeight: '600', lineHeight: '34px', bottom: '0px' }}>{name} Share Price Live</h1>
              <button className='my-1' style={{ borderRadius: '8px', height: '30px', width: '55px', backgroundColor: '#777d87', color: 'white', boxShadow: 'inset 0 0 0 1px #777d87' }}>NSE</button>
              <span className='mx-3' style={normal} onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}></span>
            </div>
            <h5 className='mx-3' style={{ position: 'relative', bottom: '4px', color: '#2a394e' }}>{name}</h5>
            <h5 className='mx-3 ' style={{ color: '#777d87', position: 'relative', bottom: '6px' }}>Large Cap  |  IT - Software</h5>
            <div className='mx-3' style={{ display: 'flex' }}>
              {/* <h3>₹{arr[0][3]}</h3> */}
              <button className='mx-3' style={{ color: 'white', backgroundColor: 'rgb(10 211 46)', width: '80px', height: '35px', borderRadius: '8px', opacity: '1' }} onClick={handleOnClick}>BUY</button>
              <button disabled={isSell===true ? false : true} className='' style={{ color: 'white', backgroundColor: 'green', width: '80px', height: '35px', borderRadius: '8px', opacity: isSell === false ? '0.5' : '1' }} onClick={sellHandle}>SELL</button>
            </div>
            <div className='mx-3 my-2' style={{ backgroundColor: 'rgba(255,174,17,.2)', display: 'flex', width: '500px', height: '30px' }}>
              <p className='mx-3 my-1' style={{ color: '#2a394e', fontWeight: '600' }}>Price as of 30 Apr 2024 15:14 .  <Link to="/" style={{ textDecoration: 'none' }}>Log in</Link> to view Live prices</p>
            </div>
            <h2 className='mx-3 my-1'>{fullName} Performance</h2>
            <h5 className='mx-3 my-4' style={{ color: '#777d87' }}>Days Range</h5>
            <div className='mx-3 my-2' style={{ display: 'flex' }}>
              {/* <p style={{ color: '#2a394e', fontWeight: 'bold', position: 'relative', left: '16px' }}>Low:₹{arr[0][2]}</p> */}
              <svg className='' style={{ position: 'relative', left: `${arrowState}px` }} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" color="#f20a3c" fill="none">
                <path d="M18 9.00005C18 9.00005 13.5811 15 12 15C10.4188 15 6 9 6 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <p className='my-3 mx-1' style={{ height: '10px', width: '500px', backgroundColor: 'red', borderRadius: '8px' }}></p>
              {/* <p style={{ color: '#2a394e', fontWeight: 'bold' }}>High:{arr[0][1]}</p> */}
            </div>
            <div>
              <div className='mx-3' style={{ display: 'flex', flexDirection: 'row' }}>
                <table className='table' style={{ width: '25%', backgroundColor: '#e0e0ec' }}>
                  <tbody>
                    <tr>
                      <td style={{ color: '#777d87', fontWeight: 'bold' }}>Open</td>
                      {/* <td style={{ fontWeight: 'bold', color: 'black',position:'absolute',left:'280px'}}>{arr[0][0]}</td> */}
                    </tr>
                    <tr>
                      <td style={{ color: '#777d87', fontWeight: 'bold' }}>Close</td>
                      {/* <td style={{ fontWeight: 'bold', color: 'black',position:'absolute',left:'280px' }}>{arr[0][3]}</td> */}
                    </tr>
                    <tr>
                      <td style={{ color: '#777d87', fontWeight: 'bold' }}>Volume</td>
                      {/* <td style={{ fontWeight: 'bold', color: 'black',position:'absolute',left:'270px' }}>{arr[0][4]}</td> */}
                    </tr>
                  </tbody>
                </table>
                <table className='table mx-3' style={{ width: '25%', backgroundColor: '#e0e0ec' }}>
                  <tbody>
                    <tr>
                      <td style={{ color: '#777d87', fontWeight: 'bold' }}>Low</td>
                      {/* <td style={{ fontWeight: 'bold', color: 'black' ,position:'absolute',left:'650px'}}>{arr[0][2]}</td> */}
                    </tr>
                    <tr>
                      <td style={{ color: '#777d87', fontWeight: 'bold' }}>High</td>
                      {/* <td style={{ fontWeight: 'bold', color: 'black',position:'absolute',left:'650px'}}>{arr[0][1]}</td> */}
                    </tr>
                    <tr>
                      <td style={{ color: '#777d87', fontWeight: 'bold' }}>Volume</td>
                      <td style={{ fontWeight: 'bold', color: 'black', position: 'absolute', left: '625px' }}>1725274</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  return null;
};

export default SeprateShare;


