import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import stockContext from './stockContext';

const SecondNav = (props) => {
  const a = useContext(stockContext);

  const linkStyle = {
    textDecoration: 'none',
    color: props.textColor,
    fontSize: '18px',
    position: 'relative',
    left: '64px',

  };

  const hoverStyle = {
    color: props.hoverColor, // Change color on hover
    textDecoration: 'underline',
    boxShadow:"box-shadow: 0 8px 24px 0 rgba(16,39,112,.2);"
  };

  const handleMouseEnter = (e) => {
    const mergedStyle = { ...linkStyle, ...hoverStyle };
    Object.assign(e.target.style, mergedStyle);
  };

  const handleMouseLeave = (e) => {
    Object.assign(e.target.style, linkStyle);
  };

  const { home, backColor, textColor, hoverColor } = props;

  return (
    <div className={`${textColor} ${hoverColor}`} style={{ position: 'sticky' }}>
      <nav style={{ display: 'flex', backgroundColor: backColor, height: '50px', alignItems: 'center' }}>
        <Link  to="/" style={linkStyle} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          {home}
        </Link>
      {a.isLoginButton ? 
        <Link to="/history" style={linkStyle} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Order History
        </Link>
       : ""}
       
        <Link to="/portfolio" style={linkStyle} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Portfolio
        </Link>
       
        {a.isLoginButton ?
        <Link to="/funds" style={linkStyle} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Add Funds
        </Link>
        :''}
        {a.isLoginButton ?
        <Link to="/transiction" style={linkStyle} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Transaction History
        </Link>
        :''}
        <Link to="/signup" style={linkStyle} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Sign up
        </Link>
        {a.isLoginButton ?
        <Link to="/profile" style={linkStyle} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Profile
        </Link>
          :''}
        <Link to="/login" style={{ ...linkStyle, display: a.isLoginButton === true ? 'block' : 'none' }} className="mx-3" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
          Login
        </Link>
      </nav>
    </div>
  );
};

export default SecondNav;
