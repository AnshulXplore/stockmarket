import React, { useEffect, useContext, useState } from 'react';
import stockContext from "./stockContext";
import './style/transiction.css';
import SecondNav from './secondnav';

export default function Transiction(props) {
    const [reasult, setreasult] = useState("");
    const[amount,setamount]=useState(0);
    const a = useContext(stockContext);

    useEffect(() => {
        const fetchdata = async () => {
            const data = await fetch('http://localhost:5000/payment/getdetail', {
                method: 'GET',
                headers: { 'Content-Type': 'application/json', 'auth-token': a.jwtToken }
            });
            const response = await data.json();
            setreasult(response);
            setamount(response.amount);
            console.log(response)
        };
        fetchdata();
        console.log(reasult)
    }, [a.jwtToken]);


if(!reasult.msg && reasult!=""){ // yeha pe dono condition isliye lagayi kyukli pehle reasult ki value empty string hai or sabse pehle return function chlta hai to agar hum reasult!="" ye lagate to ye galat hota to ye isko andar nahi jaane deta par avgar return ke baad jab useeffect run hota or reasult ke andat koi value nahi aati or hum api se koi value na aane par bhej rhe hai no history found to ye ab if condition true ho jaati or object.value ek string ko object main kaise convert karega to ye error deta or jab akele !reasult.msg likhte to iski pehle return function ke saatrh hi error de deta kyu pehle iski value empty string hai or onject.values ek empty struing ke liye error deta isliye && lagana jaruri hai or || ye bhi use nahi karsakte kyuki pehle ye ek check karta empty string or baad main message aa jata to ye error deta theek kyuki msg ek string hai or agar shru main msg likhta kuch is type se  (!reasult.msg || reasult!="" to ek true hoti or par abhi to ye empty string hai to phir object.values empty string ke liye error deta theek isliye && jaruri hai.,
    return (
        <>
            <SecondNav home={'Stocks And Performance'} backColor={'rgb(11 7 62 / 81%)'} textColor={'white'} hoverColor={'pink'}/>
            <div style={{backgroundColor:'#222',height:'100vh'}}>

            <div  className="wrapper rounded">
                <nav className="navbar navbar-expand-lg navbar-dark dark d-lg-flex align-items-lg-start">
                    <a className="navbar-brand" href="#!">Transactions
                        <p className="text-muted pl-1">Welcome to your transactions</p>
                    </a>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav ml-lg-auto">
                            <li className="nav-item">
                                <a className="nav-link" href="#!"><span className="fa fa-bell-o font-weight-bold"></span> <span className="notify">Notifications</span> </a>
                            </li>
                            <li className="nav-item">
                                <a href="#!"><span className="fa fa-search"></span></a>
                                <input type="search" className="dark" placeholder="Search" />
                            </li>
                        </ul>
                    </div>
                </nav>

                <div className="row mt-2 pt-2">
                    <div className="col-md-6" id="income">
                        <div className="d-flex justify-content-start align-items-center">
                            <p className="fa fa-long-arrow-down"></p>
                            <p className="text mx-3">Income</p>
                            <p className="text-white ml-4 money">$9,758.23</p>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="d-flex justify-content-md-end align-items-center">
                            <div className="fa fa-long-arrow-up"></div>
                            <div className="text mx-3">Amount</div>
                            <div className="text-white ml-4 money">${amount}</div>
                        </div>
                    </div>
                </div>

                <div className="d-flex justify-content-between align-items-center mt-3">
                    <ul className="nav nav-tabs w-75">
                        <li className="nav-item">
                            <a className="nav-link active" href="#history">History</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#!">Reports</a>
                        </li>
                    </ul>
                    <button className="btn btn-primary">New Transaction</button>
                </div>

                <div className="table-responsive mt-3">
                    <table className="table table-dark table-borderless">
                        <thead>
                            <tr>
                                <th scope="col">Card Number</th>
                                <th scope="col">Mode</th>
                                <th scope="col">Date</th>
                                <th style={{position:'relative'}} scope="col" className="text-right mx-5">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            {Object.values(reasult.allPayment).map((e, index) => (
                                <tr >
                                    <td scope="row"> <span className="fa fa-briefcase mr-1"></span> {e.card} </td>
                                    <td><span className="fa fa-cc-visa"></span></td>
                                    <td className="text-muted">{e.Date}</td>
                                    <td className="d-flex justify-content-end align-items-center">
                                        <span className="fa fa-long-arrow-up mr-1"></span>{e.enteramount}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="d-flex justify-content-between align-items-center results">
                    <span className="pl-md-3">Showing<b className="text-white"> {reasult.allPayment.length} 0f {reasult.allPayment.length} </b> transactions</span>
                    <div className="pt-3">
                        <nav aria-label="Page navigation example">
                            <ul className="pagination">
                                <li className="page-item disabled">
                                    <a className="page-link" href="#!" aria-label="Previous">
                                        <span aria-hidden="true">&lt;</span>
                                    </a>
                                </li>
                                <li className="page-item">
                                    <a className="page-link" href="#!" aria-label="Next">
                                        <span aria-hidden="true">&gt;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
</div>
        </>
    );
}
else{
    return(
        <>
        <SecondNav home={'Stocks And Performance'} backColor={'rgb(11 7 62 / 81%)'} textColor={'white'} hoverColor={'pink'}/>
        <h4 style={{display:'flex',justifyContent:'center',alignItems:'center',position:'relative',top:'180px'}}>No Transication orders. Please Add Fund from Anshul Pay</h4>
        <button style={{border:'none',backgroundColor:'#E91E63',position:'relative',top:'180px',left:'620px'}}><a className='underline-animation' style={{color:'white',fontWeight:'bold',textDecoration:'none'}} href="/">GO TO Home</a></button>
        </>
    )
}
}
