// import {  useNavigate  } from 'react-router-dom';
import { useContext, useEffect, useState } from "react";
import { ResponseContext } from "./seprateshare";
import stockContext from "./stockContext";
import Alert from './Alert'
const Buy = (props) => {

  const a=useContext(stockContext);
  const response = useContext(ResponseContext);
  const [amount, setamount] = useState(0);
  const [getamount,setup]=useState(0);
  const [enableButton, setButton] = useState(false);
  const [validForSell, setvalidForSell] = useState(true);
  const[sharenum,setsharenum]=useState(0);
  const[error,seterror]=useState("");
  const [isAlert,setAlert]=useState(false);
  // let previousCountOfShare = parseInt(a.states.myobj[props.name]);
  // const[index,setindex]=useState(0);
  

  const handle = () => {
    response.setmyContext(false);
  };

  const handle2 = async() => {

    const data = await fetch('http://localhost:5000/payment/getdetail', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json', 'auth-token': a.jwtToken }
  });
  const response = await data.json();
  // setreasult(response);
   setup(response.amount);
   console.log(response.amount)
   const input = parseInt(document.getElementsByClassName("input")[2].value, 10);
   const input4 = parseInt(document.getElementById("input4").value, 10);

if(props.Action==='BUY'){
    if(response.amount>=input4){
    const addstock=await fetch('http://localhost:5000/userdetail/addstock',{
      method:'POST',
      headers:{ 'Content-Type': 'application/json','auth-token':a.jwtToken},
      body:JSON.stringify({shareName:props.name,buyPrice:40,action:props.Action,shareNumber:input,amount:input4})
  })

  const updateamount=await fetch('http://localhost:5000/payment/updatefund',{
    method:'PUT',
    headers:{ 'Content-Type': 'application/json','auth-token':a.jwtToken},
    body:JSON.stringify({action:props.Action,price:input4})

})



  const json=await addstock.json();
  setsharenum(json.update)
  const json1=await updateamount.json();

  
}
else{
  seterror("You have not a money please add some cash");
  setAlert(true)
          setTimeout(() => {
            setAlert(false);
          }, 3000);
        
  
}
}

else{
  let input = parseInt(document.getElementById("input").value);
  console.log(sharenum,input)
  if(sharenum<input){
    seterror("You have not a share please add some share");
  setAlert(true)
          setTimeout(() => {
            setAlert(false);
          }, 3000);
  
  }
  else{
  const sellStock=await fetch('http://localhost:5000/userdetail/updatestock',{
    method:'PUT',
    headers:{ 'Content-Type': 'application/json','auth-token':a.jwtToken},
    body:JSON.stringify({shareName:props.name,buyPrice:40,action:props.Action,shareNumber:input,amount:input4})
})


const updateamount=await fetch('http://localhost:5000/payment/updatefund',{
  method:'PUT',
  headers:{ 'Content-Type': 'application/json','auth-token':a.jwtToken},
  body:JSON.stringify({action:props.Action,price:input4})
})


  const oneStockTotalNumber = await fetch('http://localhost:5000/userdetail/onesharedetail', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'auth-token': a.jwtToken },
    body:JSON.stringify({shareName:props.name})
});
const json=await sellStock.json();
const response = await oneStockTotalNumber.json();
console.log("total share"+response)





const json1=await updateamount.json();
setsharenum(response)
console.log("response"+response);
console.log('sell'+json)
}
}

  }


  const handleOnChange = () => {
    let input = document.getElementById("input").value;
    let input1 = parseInt(document.getElementsByClassName("input")[2].value*5);
    setamount(input1);
    
     if(input&&input1){
      setButton(true)
     } 
     else{
      setButton(false)
     }
    
  };

  useEffect(()=>{
    const fetchTotalNumOfShare=async()=>{
      const data = await fetch('http://localhost:5000/userdetail/onesharedetail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'auth-token': a.jwtToken },
        body:JSON.stringify({shareName:props.name})
    });
    const response = await data.json();
    setsharenum(response);
  }
  fetchTotalNumOfShare();
  },[])

  // const {order}=name;

  return (
    <>
      {/* <h1>hello{order}</h1> */}
      {isAlert ?  <Alert error={error}/> :''}
      <div
        className="mx-3"
        style={{ backgroundColor: "#ced4da", width: "1100px", position: "relative", height: "400px", top: "260px", left: "140px", borderRadius: "8px"}}>
        <div
          className="mx-4 my-2" style={{ display: "flex", position: "relative", top: "16px", fontWeight:"bold"}}>
          <h3 style={{ position: "relative", bottom: "16px" }} className="mx-2 my-4">
            {props.name}
          </h3>
          <h4 style={{ position: "relative", bottom: "16px" }} className="my-4 mx-2">$40.00{" "}</h4>
          <h4 style={{ position: "relative", top: "8px", left: "600px" }}>
            No.Share={sharenum}
          </h4>
        </div>
        <div className="mx-4">
          <button className="" style={{ border: "none", borderRadius: "8px 8px 0px 0px",position: "relative",backgroundColor: "white",right: "8px",fontWeight: "bold",fontSize: "20px",  width: "140px",
            }}
          >
            Normal
          </button>
          <button style={{ border: "none", backgroundColor: "#ced4da" }}>
            Stop Loss
          </button>
        </div>
        <div
          className="mx-3"
          style={{
            backgroundColor: "white",
            width: "97%",
            height: "67%",
            borderRadius: "8px 8px ",
          }}
        >
          <div
            className=""
            style={{ display: "flex", justifyContent: "space-evenly" }}
          >
            <h4
              className="my-4"
              style={{ position: "relative", right: "110px" }}
            >
              Action
            </h4>
            <h4
              className="my-4"
              style={{ position: "relative", right: "100px" }}
            >
              Buy Price
            </h4>
            <h4
              className="my-4"
              style={{ position: "relative", right: "100px" }}
            >
              Quantity
            </h4>
            <h4
              className="my-4"
              style={{ position: "relative", right: "100px" }}
            >
              Amount
            </h4>
          </div>
          <div style={{ display: "flex", justifyContent: "space-evenly" }}>
            <input
              className="input"
              style={{
                position: "relative",
                bottom: "16px",
                right: "30px",
                marginRight: "0px",
                border: "none",
                borderBottom: "1px solid black",
                outline: "none",
              }}
              type="text"
              defaultValue={props.Action}
              readOnly
            />
            <input  className="input"  style={{position: "relative" ,bottom: "16px",right: "55px",marginLeft: "0px",border: "none" ,   borderBottom: "1px solid black",outline: "none",backgroundColor:'white'}}
              type="text"
              defaultValue={props.name}
              readOnly
            />
            <input
              id="input"
              onChange={handleOnChange}
              className="input"
              style={{
                position: "relative",
                bottom: "16px",
                right: "70px",
                border: "none",
                borderBottom: "1px solid black",
                outline: "none",
              }}
              type="Number"
              defaultValue={0}
            />
            <input
              id="input4"
              className="input"
              style={{
                position: "relative",
                bottom: "16px",
                right: "80px",
                border: "none",
                borderBottom: "1px solid black",
                outline: "none",
              }}
              type="Number"
              value={amount}
              readOnly
            />
          </div>
          <div className="my-4" style={{ display: "flex" }}>
            <h5
              style={{
                position: "relative",
                left: "17px",
                color: "#777d87",
                fontWeight: "bold",
              }}
              className="mx-3 my-2"
            >
              Exchange
            </h5>
            <h5
              className=" my-2"
              style={{
                position: "relative",
                left: "17px",
                color: "#777d87",
                fontWeight: "bold",
              }}
            >
              Validity
            </h5>
            <h5 className="mx-3 my-2" style={{position: "relative",  left: "17px",  color: "#777d87",  fontWeight: "bold",}}>Product-Type </h5>
          </div>
          <div className="" style={{ display: "flex" }}>
            <h6 className="mx-3"style={{position: "relative", left: "35px", fontWeight: "bold", bottom: "20px"}}>NSE</h6>
            <h6
              className="mx-3"
              style={{
                position: "relative",
                left: "70px",
                fontWeight: "bold",
                bottom: "20px",
              }}
            >
              DAY
            </h6>
            <h6
              className="mx-3"
              style={{
                position: "relative",
                left: "95px",
                fontWeight: "bold",
                bottom: "20px",
              }}
            >
              DELIVERY
            </h6>
          </div>
          <div>
            <button style={{  position: "relative",  border: "none",  background: "transparent",  left: "700px",  color: "#777d87", }} className="mx-3" onClick={handle}>Cancel</button>

            <button disabled={enableButton === true ? false : true} style={{position: "relative",border: "1px solid blue",background: "transparent",opacity: enableButton === true ? "1" : "0.5",  left: "700px",color: "blue",borderRadius: "8px",}} onClick={handle2}> Submit</button>
          </div>
        </div>
      </div>
    </>
  );
};

Buy.defaultProps = {
  Action: "",
  shareprice: "",
  name: "",
  currentPrice: "",
  keyname: "",
  avaliableAmount: "",
  amountSetter:"",
  Index: "",
  setIndex: "",
};

export default Buy;
